#Password Generator

##Installation


* Update and upgrade your machine
```bash
$ apt update && apt upgrade
```
* Clone project
```bash
$ git clone https://github.com/WIZARD00007/PasswordGenerator
```
* Installing requirements
```bash
$ python3 setup.py 
```
* Generating password
```bash
$ python3 payload.py
```
